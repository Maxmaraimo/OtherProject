<?php
/**
 * The template for displaying the footer.
 *
 * @package nasatheme
 */
?>
</main>
<!-- End Main Content Site -->

<?php
/**
 *  Footer Site 
 */
do_action('nasa_footer_layout_style'); ?>

</div>
<!-- End Wrapper Site -->

<?php
wp_footer();
echo '</body></html>';
