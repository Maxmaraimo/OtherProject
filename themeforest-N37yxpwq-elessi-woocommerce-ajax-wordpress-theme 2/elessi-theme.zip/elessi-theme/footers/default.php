<div class="footer-content hidden-tag">
    <div class="footer-type-default">
        <div class="row">
            <div class="large-12 columns">
                <?php 
                /**
                 * Fixed footer when not select
                 * echo esc_html__('Please Define footer type in Apperance > NasaTheme Options > Header and Footer', 'elessi-theme');
                 */
                ?>
            </div>
        </div>
    </div>
</div>