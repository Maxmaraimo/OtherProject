<?php

/**
 * Checkout Form
 *
 * @author  NasaTheme
 * @package Elessi-theme/WooCommerce
 * @version 3.5.0
 */

if (!defined('ABSPATH')) :
    exit; // Exit if accessed directly
endif;

do_action('nasa_checkout_form_layout', $checkout);
